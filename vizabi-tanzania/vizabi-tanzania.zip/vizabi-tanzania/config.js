var CONFIG = {
 "data": {
  "path": "./data/tanzania2.csv",
  "reader": "csv",
  "ddfPath": "./data/tanzania2.csv"
 }
};